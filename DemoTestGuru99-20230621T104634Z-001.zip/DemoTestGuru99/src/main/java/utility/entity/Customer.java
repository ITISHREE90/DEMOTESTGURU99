package utility.entity;

public class Customer {

    public String cusId;
    public String name;
    public String gender;
    public String dateOfBirth;
    public String address;
    public String city;
    public String state;
    public String pin;
    public String telephone;
    public String email;
    public String passWord;

    public Customer() {
    }
}

