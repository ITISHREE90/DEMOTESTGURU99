package utility.entity;

public class Deposit {

    public String transId;
    public String accId;
    public String amount;
    public String typeOfTransaction;
    public String description;
    public String currentBalance;

    public Deposit() {}
}

