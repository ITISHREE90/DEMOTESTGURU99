package utility.entity;

public class Account{

    public String accId;
    public String cusId;
    public String cusName;
    public String cusEmail;
    public String accType;
    public String dateOpening;
    public String currentAmount;

    public Account() {}
}

