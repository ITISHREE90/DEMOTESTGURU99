package models;

public class SignupElement {
    public String ele_label_guru_bar = "xpath:::.//h2[@class='barone']";
    public String ele_label_form_title = "xpath:::.//form[@name='frmLogin']//h2";
    public String ele_label_email = "xpath:::.//td[@align='right']";
    public String ele_input_email = "xpath:::.//input[@name='emailid']";
    public String ele_btn_submit = "xpath:::.//input[@value='Submit']";
}
