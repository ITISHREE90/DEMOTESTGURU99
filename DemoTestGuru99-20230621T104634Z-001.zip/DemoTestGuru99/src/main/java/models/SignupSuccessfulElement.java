package models;

public class SignupSuccessfulElement {
    public String ele_label_guru_bar = "xpath:::.//h2[@class='barone']";
    public String ele_table_title = "xpath:::.//table//h2";
    public String ele_label_id_text = "xpath:::.//tr[4]/td[@class='accpage']";
    public String ele_label_id_value = "xpath:::.//tr[4]/td[not(contains(@class,'accpage'))]";
    public String ele_label_password_text = "xpath:::.//tr[5]/td[@class='accpage']";
    public String ele_label_password_value = "xpath:::.//tr[5]/td[not(contains(@class,'accpage'))]";
    public String ele_label_note = "xpath:::.//h3";
}
